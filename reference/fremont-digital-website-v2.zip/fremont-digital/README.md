# Fremont Digital — Website v2

A custom-coded, responsive one-page website for Fremont Digital.

## Open the website
Open `index.html` in a web browser. It works without a build step, framework, or external services. The ZIP contains all website files, including the existing Fremont Digital monogram.

## Site map
- Hero with interactive-style visual design demonstration
- Introduction and business positioning
- Two switchable original design concept studies (fictional, not client work)
- Web design, digital marketing, tech support, and basic device repair offerings
- Working process, FAQ, and inquiry section

## Before publishing

1. **Connect an email address**: In `main.js`, change `const CONTACT_EMAIL = '';` to your actual business inbox, e.g. `const CONTACT_EMAIL = 'you@yourdomain.com';`. The form will then open a customer's email application with a ready-to-send message. With no email configured, it copies the inquiry to the clipboard and clearly states that it has not been sent. For a real on-page submission form with delivery, connect an actual form provider/server endpoint instead. Never claim the clipboard mode sends a message.
2. **Connect your actual contact channels**: Consider adding your verified Facebook business page link, business phone number, or domain once available.
3. **Review all service claims**: Adjust the repair language to match the devices and repairs you actually handle.
4. **Verify the business name and domain**: Another business has used “Fremont Digital.” Check state records and potential trademark conflicts before launch.
5. **Replace concept work with real project work over time**: The two illustrated website examples are original visual demonstrations for fictional brands. They are explicitly not testimonials or completed client jobs.
6. **Review on real devices**: Test contact behavior on iPhone/Android, major browsers, and confirm all user-provided information before going live.

## Files
- `index.html` — semantic HTML
- `styles.css` — responsive art direction and page styling
- `main.js` — menu, accessible concept tabs, scroll reveals, inquiry handler
- `assets/fd-mark.png` — existing Fremont Digital FD monogram
- `assets/favicon.png` — favicon

## Technical notes
- Mobile navigation has Escape-to-close, and the concept gallery has arrow-key navigation.
- Reduced-motion users do not receive motion effects.
- No fabricated reviews, awards, client results, or specific promises of ranking/revenue increases.
- No external image loading, trackers, CDN assets, or libraries are required.

This is a polished frontend prototype, not a fully configured commercial deployment. Contact delivery and your business-specific launch information are still needed.
