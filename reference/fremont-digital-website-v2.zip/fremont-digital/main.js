// Fremont Digital website. Set the email address below before publishing to enable direct inquiries.
const CONTACT_EMAIL = '';

const menuButton = document.getElementById('nav-toggle');
const mobileMenu = document.getElementById('nav-mobile');
function closeMenu(){ menuButton.setAttribute('aria-expanded','false'); menuButton.setAttribute('aria-label','Open menu'); mobileMenu.hidden=true; }
menuButton.addEventListener('click',()=>{const opening=menuButton.getAttribute('aria-expanded')!=='true';menuButton.setAttribute('aria-expanded', String(opening));menuButton.setAttribute('aria-label',opening?'Close menu':'Open menu');mobileMenu.hidden=!opening;});
mobileMenu.querySelectorAll('a').forEach(a=>a.addEventListener('click',closeMenu));
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu();});

const tabs=[...document.querySelectorAll('.gallery-tab')];
const panels=[...document.querySelectorAll('.gallery-panel')];
function switchConcept(index,focus=false){tabs.forEach((tab,i)=>{const active=i===index;tab.classList.toggle('active',active);tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1;panels[i].hidden=!active;});if(focus)tabs[index].focus();}
tabs.forEach((tab,index)=>{tab.addEventListener('click',()=>switchConcept(index));tab.addEventListener('keydown',e=>{if(['ArrowRight','ArrowLeft','Home','End'].includes(e.key)){e.preventDefault();const next=e.key==='Home'?0:e.key==='End'?tabs.length-1:(index+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;switchConcept(next,true);}});});

const form=document.getElementById('inquiry-form');
const note=document.getElementById('form-note');
const submitLabel=document.getElementById('submit-label');
if(CONTACT_EMAIL){submitLabel.textContent='OPEN EMAIL TO SEND';note.textContent='This will open your email app with your project details ready to send.';}
form.addEventListener('submit',async e=>{
  e.preventDefault();
  const name=document.getElementById('client-name').value.trim();
  const contact=document.getElementById('client-contact').value.trim();
  const service=document.getElementById('client-type').value;
  const message=document.getElementById('client-message').value.trim();
  note.classList.remove('error','success');
  if(!name||!contact||!message){note.classList.add('error');note.textContent='Please add your name, a contact method, and a little about the project.';return;}
  const subject=`Fremont Digital inquiry — ${service}`;
  const inquiry=`${subject}\n\nName: ${name}\nContact: ${contact}\nService: ${service}\n\nProject details:\n${message}`;
  if(CONTACT_EMAIL){window.location.href=`mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(inquiry)}`;note.classList.add('success');note.textContent='Your email app should open with the details ready to send. Please send the email from there.';return;}
  try{if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(inquiry);}else{const t=document.createElement('textarea');t.value=inquiry;t.style.position='fixed';t.style.top='-9999px';document.body.append(t);t.select();if(!document.execCommand('copy'))throw new Error('Clipboard unavailable');t.remove();}note.classList.add('success');note.textContent='Inquiry copied. Paste it into your message to Fremont Digital. (Direct delivery is not connected yet.)';submitLabel.textContent='COPIED — THANK YOU';setTimeout(()=>{submitLabel.textContent='COPY MY INQUIRY'},4000);}catch(err){note.classList.add('error');note.textContent='Could not access the clipboard. Please copy your details manually.';}
});
document.getElementById('year').textContent=String(new Date().getFullYear());

// Progressive scroll reveals; content stays visible where IntersectionObserver is unsupported.
if('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches){
  document.documentElement.classList.add('js-ready');
  const observer=new IntersectionObserver((entries)=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target);}});},{threshold:0.09,rootMargin:'0px 0px -30px 0px'});
  document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));
}
