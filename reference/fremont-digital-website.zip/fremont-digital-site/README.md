# Fremont Digital — website prototype

This is a working, self-contained, responsive website prototype. Open `index.html` in a web browser.

## Included
- Full home page with four services, process, FAQ, and contact inquiry composer.
- Responsive navigation, accessible labels, on-page SEO basics, reduced-motion support.
- Brand icon extracted from your existing approved logo.
- No frameworks, build step, subscriptions, analytics, or external fonts.

## Before publication
1. **Connect a real contact method.** The current inquiry feature copies text to clipboard and **does not send**. Replace it with a proper contact form service or connect your Facebook Messenger URL and/or business email.
2. Confirm exactly which repairs, devices, and marketing services you want to take on, and adjust the wording accordingly.
3. Add real completed-project examples as you have them. No sample client work or fabricated testimonials are included.
4. Review the business name and domain for possible conflicts. Another company publicly uses **Fremont Digital LLC** and `fremontdigital.co`; do trademark and domain due diligence.
5. When you decide where to host, add the final site URL, an appropriate OG preview image, favicon variants, and a business privacy policy if you later collect personal data.

## Preview / deployment
This folder can be uploaded to any host that serves static files (Netlify, Cloudflare Pages, GitHub Pages, etc.). Do not treat the message-copying inquiry widget as a live contact form.
